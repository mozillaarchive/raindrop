require.def("dijit/form/ToggleButton", ["require", "dojo", "dijit", "dojox", "dijit/form/Button"], function(require, dojo, dijit, dojox, _R0) {
dojo.provide("dijit.form.ToggleButton");
;

return dijit.form.ToggleButton; });
