require.def("dijit/form/MappedTextBox", ["require", "dojo", "dijit", "dojox", "dijit/form/ValidationTextBox"], function(require, dojo, dijit, dojox, _R0) {
dojo.provide("dijit.form.MappedTextBox");
;

return dijit.form.MappedTextBox; });
