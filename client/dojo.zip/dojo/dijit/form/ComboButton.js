require.def("dijit/form/ComboButton", ["require", "dojo", "dijit", "dojox", "dijit/form/Button"], function(require, dojo, dijit, dojox, _R0) {
dojo.provide("dijit.form.ComboButton");
;

return dijit.form.ComboButton; });
