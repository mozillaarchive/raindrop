require.def("dijit/form/RangeBoundTextBox", ["require", "dojo", "dijit", "dojox", "dijit/form/ValidationTextBox"], function(require, dojo, dijit, dojox, _R0) {
dojo.provide("dijit.form.RangeBoundTextBox");
;

return dijit.form.RangeBoundTextBox; });
