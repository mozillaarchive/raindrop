require.def("dijit/form/RadioButton", ["require", "dojo", "dijit", "dojox", "dijit/form/CheckBox"], function(require, dojo, dijit, dojox, _R0) {
dojo.provide("dijit.form.RadioButton");
;

// TODO: for 2.0, move the RadioButton code into this file

return dijit.form.RadioButton; });
