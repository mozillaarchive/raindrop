require.def("i18n!dijit/form/nls/sk/ComboBox",
{
		previousMessage: "Predchádzajúce voľby",
		nextMessage: "Ďalšie voľby"
});
