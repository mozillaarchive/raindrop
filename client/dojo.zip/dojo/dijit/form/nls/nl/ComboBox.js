require.def("i18n!dijit/form/nls/nl/ComboBox",
{
		previousMessage: "Eerdere opties",
		nextMessage: "Meer opties"
});
