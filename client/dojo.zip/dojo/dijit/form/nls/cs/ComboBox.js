require.def("i18n!dijit/form/nls/cs/ComboBox",
{
		previousMessage: "Předchozí volby",
		nextMessage: "Další volby"
});
