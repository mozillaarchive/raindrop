require.def("i18n!dijit/form/nls/ComboBox",
{ "root": {
		previousMessage: "Previous choices",
		nextMessage: "More choices"
},
"ar": true,
"ca": true
});
