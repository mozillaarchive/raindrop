require.def("i18n!dijit/form/nls/zh/validate",
{
	invalidMessage: "输入的值无效。",
	missingMessage: "此值是必需值。",
	rangeMessage: "此值超出范围。"
});
