require.def("i18n!dijit/form/nls/it/ComboBox",
{
		previousMessage: "Scelte precedenti",
		nextMessage: "Altre scelte"
});
