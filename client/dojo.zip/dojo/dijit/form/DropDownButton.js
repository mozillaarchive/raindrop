require.def("dijit/form/DropDownButton", ["require", "dojo", "dijit", "dojox", "dijit/form/Button"], function(require, dojo, dijit, dojox, _R0) {
dojo.provide("dijit.form.DropDownButton");
;


return dijit.form.DropDownButton; });
