console.warn("dijit-all may include much more code than your application actually requires. We strongly recommend that you investigate a custom build or the web build tool");
require.def("dijit/dijit-all", ["require", "dojo", "dijit", "dojox", "dijit/dijit", "dijit/ColorPalette", "dijit/Declaration", "dijit/Dialog", "dijit/DialogUnderlay", "dijit/TooltipDialog", "dijit/Editor", "dijit/Menu", "dijit/MenuItem", "dijit/PopupMenuItem", "dijit/MenuBar", "dijit/MenuBarItem", "dijit/PopupMenuBarItem", "dijit/MenuSeparator", "dijit/ProgressBar", "dijit/TitlePane", "dijit/Toolbar", "dijit/Tooltip", "dijit/Tree", "dijit/InlineEditBox", "dijit/form/Form", "dijit/form/Button", "dijit/form/DropDownButton", "dijit/form/ComboButton", "dijit/form/ToggleButton", "dijit/form/CheckBox", "dijit/form/RadioButton", "dijit/form/TextBox", "dijit/form/ValidationTextBox", "dijit/form/CurrencyTextBox", "dijit/form/DateTextBox", "dijit/form/NumberSpinner", "dijit/form/NumberTextBox", "dijit/form/ComboBox", "dijit/form/FilteringSelect", "dijit/form/MultiSelect", "dijit/form/HorizontalSlider", "dijit/form/VerticalSlider", "dijit/form/HorizontalRule", "dijit/form/VerticalRule", "dijit/form/HorizontalRuleLabels", "dijit/form/VerticalRuleLabels", "dijit/form/SimpleTextarea", "dijit/form/Textarea", "dijit/layout/AccordionContainer", "dijit/layout/ContentPane", "dijit/layout/BorderContainer", "dijit/layout/LayoutContainer", "dijit/layout/LinkPane", "dijit/layout/SplitContainer", "dijit/layout/StackContainer", "dijit/layout/TabContainer"], function(require, dojo, dijit, dojox, _R0, _R1, _R2, _R3, _R4, _R5, _R6, _R7, _R8, _R9, _R10, _R11, _R12, _R13, _R14, _R15, _R16, _R17, _R18, _R19, _R20, _R21, _R22, _R23, _R24, _R25, _R26, _R27, _R28, _R29, _R30, _R31, _R32, _R33, _R34, _R35, _R36, _R37, _R38, _R39, _R40, _R41, _R42, _R43, _R44, _R45, _R46, _R47, _R48, _R49, _R50, _R51) {
dojo.provide("dijit.dijit-all");

/*=====
dijit["dijit-all"] = {
	// summary:
	//		A rollup that includes every dijit. You probably don't need this.
};
=====*/

;

;
;

;
;
;

;

;
;
;
;
;
;
;

;
;
;
;
;
;

// Form widgets
;

// Button widgets
;
;
;
;
;
;

// Textbox widgets
;
;
;
;
;
;

// Select widgets
;
;
;

// Slider widgets
;
;
;
;
;
;

// Textarea widgets
;
;

// Layout widgets
;
;
;
; //deprecated
;
; //deprecated
;
;

return null; });
