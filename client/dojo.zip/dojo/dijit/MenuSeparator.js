require.def("dijit/MenuSeparator", ["require", "dojo", "dijit", "dojox", "dijit/_Widget", "dijit/_Templated", "dijit/_Contained", 'text!dijit/templates/MenuSeparator!html!<tr class="dijitMenuSeparator">\n\t<td colspan="4">\n\t\t<div class="dijitMenuSeparatorTop"></div>\n\t\t<div class="dijitMenuSeparatorBottom"></div>\n\t</td>\n</tr>\n'], function(require, dojo, dijit, dojox, _R0, _R1, _R2, _R3) {
dojo.provide("dijit.MenuSeparator");

;
;
;

dojo.declare("dijit.MenuSeparator",
		[dijit._Widget, dijit._Templated, dijit._Contained],
		{
		// summary:
		//		A line between two menu items

		templateString: _R3,

		postCreate: function(){
			dojo.setSelectable(this.domNode, false);
		},

		isFocusable: function(){
			// summary:
			//		Override to always return false
			// tags:
			//		protected

			return false; // Boolean
		}
	});


return dijit.MenuSeparator; });
