require.def("i18n!dijit/nls/ar/loading",
{
	loadingState: "جاري التحميل...",
	errorState: "عفوا، حدث خطأ"
});
