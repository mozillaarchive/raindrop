require.def("i18n!dijit/nls/th/loading",
{
	loadingState: "กำลังโหลด...",
	errorState: "ขออภัย เกิดข้อผิดพลาด"
});
