require.def("i18n!dijit/nls/tr/loading",
{
	loadingState: "Yükleniyor...",
	errorState: "Üzgünüz, bir hata oluştu"
});
