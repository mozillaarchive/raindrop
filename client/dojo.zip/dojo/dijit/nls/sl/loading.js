require.def("i18n!dijit/nls/sl/loading",
{
	loadingState: "Nalaganje...",
	errorState: "Oprostite, prišlo je do napake."
});
