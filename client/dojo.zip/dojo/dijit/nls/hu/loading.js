require.def("i18n!dijit/nls/hu/loading",
{
	loadingState: "Betöltés...",
	errorState: "Sajnálom, hiba történt"
});
