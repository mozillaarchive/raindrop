require.def("i18n!dijit/nls/common",
{ "root": {
	buttonOk: "OK",
	buttonCancel: "Cancel",
	buttonSave: "Save",
	itemClose: "Close"
},
"ar": true,
"ca": true
});
