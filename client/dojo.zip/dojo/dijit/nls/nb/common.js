require.def("i18n!dijit/nls/nb/common",
{
	buttonOk: "OK",
	buttonCancel: "Avbryt",
	buttonSave: "Lagre",
	itemClose: "Lukk"
});
