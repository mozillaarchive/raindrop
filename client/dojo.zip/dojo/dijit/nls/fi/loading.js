require.def("i18n!dijit/nls/fi/loading",
{
	loadingState: "Lataus on meneillään...",
	errorState: "On ilmennyt virhe."
});
