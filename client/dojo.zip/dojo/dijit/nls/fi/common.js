require.def("i18n!dijit/nls/fi/common",
{
	buttonOk: "OK",
	buttonCancel: "Peruuta",
	buttonSave: "Tallenna",
	itemClose: "Sulje"
});
