require.def("i18n!dijit/nls/el/loading",
{
	loadingState: "Φόρτωση...",
	errorState: "Σας ζητούμε συγνώμη, παρουσιάστηκε σφάλμα"
});
