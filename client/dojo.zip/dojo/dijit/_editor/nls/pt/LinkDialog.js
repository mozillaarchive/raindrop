require.def("i18n!dijit/_editor/nls/pt/LinkDialog",
{
	createLinkTitle: "Propriedades de Link",
	insertImageTitle: "Propriedades de Imagem",
	url: "URL:",
	text: "Descrição:",
	set: "Definir"
});
