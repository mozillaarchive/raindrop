require.def("i18n!dijit/_editor/nls/he/LinkDialog",
{
	createLinkTitle: "תכונות קישור",
	insertImageTitle: "תכונות תמונה",
	url: "URL:‏",
	text: "תיאור:",
	set: "הגדרה"
});
