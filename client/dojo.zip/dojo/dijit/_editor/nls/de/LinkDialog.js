require.def("i18n!dijit/_editor/nls/de/LinkDialog",
{
	createLinkTitle: "Linkeigenschaften",
	insertImageTitle: "Grafikeigenschaften",
	url: "URL:",
	text: "Beschreibung:",
	set: "Festlegen"
});
