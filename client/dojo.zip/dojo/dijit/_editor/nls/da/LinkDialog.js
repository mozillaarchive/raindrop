require.def("i18n!dijit/_editor/nls/da/LinkDialog",
{
	createLinkTitle: "Linkegenskaber",
	insertImageTitle: "Billedegenskaber",
	url: "URL:",
	text: "Beskrivelse:",
	set: "Definér"
});
