require.def("i18n!dijit/_editor/nls/pt-pt/LinkDialog",
{
	createLinkTitle: "Propriedades da ligação",
	insertImageTitle: "Propriedades da imagem",
	url: "URL:",
	text: "Descrição:",
	set: "Definir"
});
