require.def("i18n!dijit/_editor/nls/hu/LinkDialog",
{
	createLinkTitle: "Hivatkozás tulajdonságai",
	insertImageTitle: "Kép tulajdonságai",
	url: "URL:",
	text: "Leírás:",
	set: "Beállítás"
});
