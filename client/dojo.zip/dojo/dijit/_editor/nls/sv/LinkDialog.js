require.def("i18n!dijit/_editor/nls/sv/LinkDialog",
{
	createLinkTitle: "Länkegenskaper",
	insertImageTitle: "Bildegenskaper",
	url: "URL-adress:",
	text: "Beskrivning:",
	set: "Ange"
});
