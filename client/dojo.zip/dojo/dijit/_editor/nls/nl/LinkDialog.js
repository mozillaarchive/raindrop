require.def("i18n!dijit/_editor/nls/nl/LinkDialog",
{
	createLinkTitle: "Linkeigenschappen",
	insertImageTitle: "Afbeeldingseigenschappen",
	url: "URL:",
	text: "Beschrijving:",
	set: "Instellen"
});
