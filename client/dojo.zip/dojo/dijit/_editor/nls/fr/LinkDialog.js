require.def("i18n!dijit/_editor/nls/fr/LinkDialog",
{
	createLinkTitle: "Propriétés des liens",
	insertImageTitle: "Propriétés des images",
	url: "URL :",
	text: "Description :",
	target: "Cible :",
	set: "Définir",
	currentWindow: "Fenêtre en cours",
	parentWindow: "Fenêtre parent",
	topWindow: "Première fenêtre",
	newWindow: "Nouvelle fenêtre"
});
