
(function () {
    var d = dojo, theme = false, testMode = null, defTheme = "tundra";
    if (window.location.href.indexOf("?") > -1) {
        var str = window.location.href.substr(window.location.href.indexOf("?") + 1).split(/#/);
        var ary = str[0].split(/&/);
        for (var i = 0; i < ary.length; i++) {
            var split = ary[i].split(/=/), key = split[0], value = split[1].replace(/[^\w]/g, "");
            switch (key) {
              case "locale":
                dojo.config.locale = locale = value;
                break;
              case "dir":
                document.getElementsByTagName("html")[0].dir = value;
                break;
              case "theme":
                theme = value;
                break;
              case "a11y":
                if (value) {
                    testMode = "dijit_a11y";
                }
            }
        }
    }
    if (theme || testMode) {
        if (theme) {
            var themeCss = d.moduleUrl("dijit.themes", theme + "/" + theme + ".css");
            var themeCssRtl = d.moduleUrl("dijit.themes", theme + "/" + theme + "_rtl.css");
            document.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"" + themeCss + "\">");
            document.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"" + themeCssRtl + "\">");
        }
        if (dojo.config.parseOnLoad) {
            dojo.config.parseOnLoad = false;
            dojo.config._deferParsing = true;
        }
        d.addOnLoad(function () {
            var b = dojo.body();
            if (theme) {
                dojo.removeClass(b, defTheme);
                if (!d.hasClass(b, theme)) {
                    d.addClass(b, theme);
                }
                var n = d.byId("themeStyles");
                if (n) {
                    d.destroy(n);
                }
            }
            if (testMode) {
                d.addClass(b, testMode);
            }
            if (dojo.config._deferParsing) {
                setTimeout(dojo.hitch(d.parser, "parse", b), 120);
            }
        });
    }
})();

