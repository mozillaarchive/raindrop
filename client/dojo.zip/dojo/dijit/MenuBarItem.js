require.def("dijit/MenuBarItem", ["require", "dojo", "dijit", "dojox", "dijit/MenuItem", 'text!dijit/templates/MenuBarItem!html!<div class="dijitReset dijitInline dijitMenuItem dijitMenuItemLabel" dojoAttachPoint="focusNode" waiRole="menuitem" tabIndex="-1"\'\n\t\tdojoAttachEvent="onmouseenter:_onHover,onmouseleave:_onUnhover,ondijitclick:_onClick">\n\t<span dojoAttachPoint="containerNode"></span>\n</div>\n'], function(require, dojo, dijit, dojox, _R0, _R1) {
dojo.provide("dijit.MenuBarItem");

;

dojo.declare("dijit._MenuBarItemMixin", null, {
	templateString: _R1,

	// overriding attributeMap because we don't have icon
	attributeMap: dojo.delegate(dijit._Widget.prototype.attributeMap, {
		label: { node: "containerNode", type: "innerHTML" }
	})
});

dojo.declare("dijit.MenuBarItem", [dijit.MenuItem, dijit._MenuBarItemMixin], {
	// summary:
	//		Item in a MenuBar that's clickable, and doesn't spawn a submenu when pressed (or hovered)

});

return dijit.MenuBarItem; });
