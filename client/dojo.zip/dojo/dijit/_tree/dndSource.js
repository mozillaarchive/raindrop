require.def("dijit/_tree/dndSource", ["require", "dojo", "dijit", "dojox", "dijit/tree/dndSource"], function(require, dojo, dijit, dojox, _R0) {
dojo.provide("dijit._tree.dndSource");
;

// TODO: remove this file in 2.0
dojo.deprecated("dijit._tree.dndSource has been moved to dijit.tree.dndSource, use that instead", "", "2.0");

dijit._tree.dndSource = dijit.tree.dndSource;

return dijit._tree.dndSource; });
