require.def("dijit/PopupMenuBarItem", ["require", "dojo", "dijit", "dojox", "dijit/PopupMenuItem", "dijit/MenuBarItem"], function(require, dojo, dijit, dojox, _R0, _R1) {
dojo.provide("dijit.PopupMenuBarItem");

;
;

dojo.declare("dijit.PopupMenuBarItem", [dijit.PopupMenuItem, dijit._MenuBarItemMixin], {
	// summary:
	//		Item in a MenuBar like "File" or "Edit", that spawns a submenu when pressed (or hovered)
});


return dijit.PopupMenuBarItem; });
